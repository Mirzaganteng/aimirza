/**
 * NEXUS AI - Settings Manager
 * Handles settings modal, temperature, system prompt, etc.
 */

const SettingsManager = {
  currentSettings: {},

  init: () => {
    SettingsManager.currentSettings = StorageManager.getSettings();
  },

  openSettingsModal: () => {
    const modal = document.getElementById('settings-modal');
    if (!modal) return;

    // Populate current values
    const settings = StorageManager.getSettings();

    // Sliders
    const tempSlider = document.getElementById('temp-slider');
    const tempValue = document.getElementById('temp-value');
    if (tempSlider) {
      tempSlider.value = settings.temperature;
      tempValue.textContent = settings.temperature;
      tempSlider.oninput = () => {
        tempValue.textContent = tempSlider.value;
      };
    }

    const topPSlider = document.getElementById('topp-slider');
    const topPValue = document.getElementById('topp-value');
    if (topPSlider) {
      topPSlider.value = settings.topP;
      topPValue.textContent = settings.topP;
    }

    const maxTokensSlider = document.getElementById('maxtokens-slider');
    const maxTokensValue = document.getElementById('maxtokens-value');
    if (maxTokensSlider) {
      maxTokensSlider.value = settings.maxTokens;
      maxTokensValue.textContent = settings.maxTokens;
    }

    // Penalties
    const presenceSlider = document.getElementById('presence-slider');
    if (presenceSlider) presenceSlider.value = settings.presencePenalty || 0;

    const freqSlider = document.getElementById('frequency-slider');
    if (freqSlider) freqSlider.value = settings.frequencyPenalty || 0;

    // Textareas
    const systemPrompt = document.getElementById('system-prompt');
    if (systemPrompt) systemPrompt.value = settings.systemPrompt || '';

    const customInstructions = document.getElementById('custom-instructions');
    if (customInstructions) customInstructions.value = settings.customInstructions || '';

    // Checkboxes
    const autoSpeak = document.getElementById('auto-speak');
    if (autoSpeak) autoSpeak.checked = settings.autoSpeak || false;

    const streamResponse = document.getElementById('stream-response');
    if (streamResponse) streamResponse.checked = settings.streamResponse !== false;

    modal.classList.add('active');
  },

  saveSettings: () => {
    const newSettings = {
      temperature: parseFloat(document.getElementById('temp-slider')?.value || 0.7),
      topP: parseFloat(document.getElementById('topp-slider')?.value || 0.95),
      maxTokens: parseInt(document.getElementById('maxtokens-slider')?.value || 4096),
      presencePenalty: parseFloat(document.getElementById('presence-slider')?.value || 0),
      frequencyPenalty: parseFloat(document.getElementById('frequency-slider')?.value || 0),
      systemPrompt: document.getElementById('system-prompt')?.value || '',
      customInstructions: document.getElementById('custom-instructions')?.value || '',
      autoSpeak: document.getElementById('auto-speak')?.checked || false,
      streamResponse: document.getElementById('stream-response')?.checked !== false,
      showThinking: true
    };

    StorageManager.saveSettings(newSettings);
    SettingsManager.currentSettings = newSettings;

    // Close modal
    const modal = document.getElementById('settings-modal');
    if (modal) modal.classList.remove('active');

    // Show toast
    if (window.showToast) {
      window.showToast('Pengaturan berhasil disimpan!', 'success');
    }

    return newSettings;
  },

  getCurrentSettings: () => {
    return StorageManager.getSettings();
  },

  resetToDefaults: () => {
    const defaults = {
      temperature: 0.7,
      topP: 0.95,
      maxTokens: 4096,
      presencePenalty: 0,
      frequencyPenalty: 0,
      systemPrompt: 'Kamu adalah asisten AI yang sangat membantu, cerdas, dan ramah.',
      customInstructions: '',
      autoSpeak: false,
      streamResponse: true
    };

    StorageManager.saveSettings(defaults);
    SettingsManager.currentSettings = defaults;

    if (window.showToast) window.showToast('Pengaturan direset ke default.', 'info');
    
    // Reopen to refresh UI
    setTimeout(() => {
      const modal = document.getElementById('settings-modal');
      if (modal) modal.classList.remove('active');
      SettingsManager.openSettingsModal();
    }, 300);
  }
};

window.SettingsManager = SettingsManager;