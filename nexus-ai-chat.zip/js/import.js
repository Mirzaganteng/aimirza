/**
 * NEXUS AI - Import Chat
 */

const ImportManager = {
  importFromFile: (file, callback) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        if (file.name.endsWith('.json')) {
          const data = JSON.parse(e.target.result);
          
          // Validate structure
          if (!data.id || !data.messages) {
            throw new Error('Format JSON tidak valid untuk NEXUS AI Chat.');
          }

          // Create new chat from imported data
          const newChat = {
            id: Utils.generateId(),
            title: data.title || 'Chat Impor',
            messages: data.messages || [],
            provider: data.provider || StorageManager.getCurrentProvider(),
            model: data.model || StorageManager.getCurrentModel(),
            createdAt: data.createdAt || Date.now(),
            updatedAt: Date.now(),
            agentMode: data.agentMode || 'default',
            imported: true
          };

          // Save to storage
          const chats = StorageManager.getChats();
          chats.unshift(newChat);
          StorageManager.saveChats(chats);
          StorageManager.setCurrentChatId(newChat.id);

          if (callback) callback(newChat);
          if (window.showToast) window.showToast('Chat berhasil diimpor!', 'success');

        } else if (file.name.endsWith('.txt')) {
          // Simple TXT import
          const content = e.target.result;
          const lines = content.split('\n');
          
          const newChat = {
            id: Utils.generateId(),
            title: 'Chat Impor TXT',
            messages: [],
            provider: StorageManager.getCurrentProvider(),
            model: StorageManager.getCurrentModel(),
            createdAt: Date.now(),
            updatedAt: Date.now(),
            imported: true
          };

          let currentRole = null;
          let currentContent = '';

          lines.forEach(line => {
            if (line.startsWith('[Anda') || line.startsWith('[NEXUS')) {
              if (currentRole && currentContent) {
                newChat.messages.push({
                  role: currentRole,
                  content: currentContent.trim(),
                  timestamp: Date.now()
                });
              }
              currentRole = line.includes('[Anda') ? 'user' : 'assistant';
              currentContent = '';
            } else if (line.trim() && currentRole) {
              currentContent += line + '\n';
            }
          });

          if (currentRole && currentContent) {
            newChat.messages.push({
              role: currentRole,
              content: currentContent.trim(),
              timestamp: Date.now()
            });
          }

          const chats = StorageManager.getChats();
          chats.unshift(newChat);
          StorageManager.saveChats(chats);
          StorageManager.setCurrentChatId(newChat.id);

          if (callback) callback(newChat);
          if (window.showToast) window.showToast('Chat TXT berhasil diimpor', 'success');
        }
      } catch (err) {
        console.error('Import error:', err);
        if (window.showToast) window.showToast('Gagal mengimpor: ' + err.message, 'error');
      }
    };

    reader.onerror = () => {
      if (window.showToast) window.showToast('Gagal membaca file.', 'error');
    };

    if (file.name.endsWith('.json')) {
      reader.readAsText(file);
    } else {
      reader.readAsText(file);
    }
  }
};

window.ImportManager = ImportManager;