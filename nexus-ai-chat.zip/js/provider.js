/**
 * NEXUS AI - Provider Configuration
 * All supported AI providers, models, and API configurations
 */

const ProviderConfig = {
  providers: {
    'OpenAI GPT': {
      name: 'OpenAI GPT',
      icon: '🤖',
      color: '#10a37f',
      endpoint: 'https://api.openai.com/v1/chat/completions',
      models: [
        { id: 'gpt-4o', name: 'GPT-4o', context: 128000, vision: true },
        { id: 'gpt-4.1', name: 'GPT-4.1', context: 128000, vision: true },
        { id: 'gpt-5', name: 'GPT-5', context: 200000, vision: true },
        { id: 'gpt-5-mini', name: 'GPT-5 Mini', context: 128000, vision: true }
      ],
      compatible: true,
      requiresVersion: false,
      streamSupported: true,
      headers: (key) => ({
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json'
      }),
      buildBody: (messages, model, settings, stream = true) => ({
        model: model,
        messages: messages,
        stream: stream,
        temperature: settings.temperature,
        top_p: settings.topP,
        max_tokens: settings.maxTokens,
        presence_penalty: settings.presencePenalty,
        frequency_penalty: settings.frequencyPenalty
      }),
      parseResponse: (data) => {
        if (data.choices && data.choices[0]) {
          return data.choices[0].message?.content || '';
        }
        return '';
      },
      parseStreamChunk: (chunk) => {
        // OpenAI SSE format: data: {"choices":[{"delta":{"content":"..."}}]}
        if (chunk.startsWith('data: ')) {
          const jsonStr = chunk.replace('data: ', '').trim();
          if (jsonStr === '[DONE]') return { done: true };
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content || '';
            return { content, done: false };
          } catch (e) {
            return { content: '', done: false };
          }
        }
        return { content: '', done: false };
      }
    },

    'Google Gemini': {
      name: 'Google Gemini',
      icon: '✨',
      color: '#4285f4',
      // Note: For browser, we use generateContent (non-stream first for simplicity, streaming supported via SSE)
      endpoint: 'https://generativelanguage.googleapis.com/v1beta/models',
      models: [
        { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash', context: 1000000, vision: true },
        { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro', context: 2000000, vision: true }
      ],
      compatible: false,
      streamSupported: true,
      getEndpoint: (model, key) => 
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?key=${key}&alt=sse`,
      buildBody: (messages, model, settings) => {
        // Convert OpenAI messages format to Gemini
        const contents = messages.map(msg => {
          if (msg.role === 'system') {
            return { role: 'user', parts: [{ text: `SYSTEM INSTRUCTION: ${msg.content}` }] };
          }
          const role = msg.role === 'assistant' ? 'model' : 'user';
          const parts = [];
          if (typeof msg.content === 'string') {
            parts.push({ text: msg.content });
          } else if (Array.isArray(msg.content)) {
            msg.content.forEach(part => {
              if (part.type === 'text') parts.push({ text: part.text });
              if (part.type === 'image_url' && part.image_url?.url) {
                const base64 = part.image_url.url.split(',')[1];
                const mime = part.image_url.url.split(';')[0].split(':')[1];
                parts.push({
                  inline_data: { mime_type: mime, data: base64 }
                });
              }
            });
          }
          return { role, parts };
        });
        return {
          contents: contents,
          generationConfig: {
            temperature: settings.temperature,
            topP: settings.topP,
            maxOutputTokens: settings.maxTokens
          }
        };
      },
      parseStreamChunk: (chunk) => {
        if (chunk.startsWith('data: ')) {
          try {
            const jsonStr = chunk.replace('data: ', '').trim();
            const parsed = JSON.parse(jsonStr);
            const content = parsed.candidates?.[0]?.content?.parts?.[0]?.text || '';
            return { content, done: false };
          } catch (e) {
            return { content: '', done: false };
          }
        }
        return { content: '', done: false };
      }
    },

    'DeepSeek': {
      name: 'DeepSeek',
      icon: '🧠',
      color: '#1a73e8',
      endpoint: 'https://api.deepseek.com/chat/completions',
      models: [
        { id: 'deepseek-chat', name: 'DeepSeek Chat', context: 128000, vision: false },
        { id: 'deepseek-reasoner', name: 'DeepSeek Reasoner', context: 64000, vision: false }
      ],
      compatible: true,
      streamSupported: true,
      headers: (key) => ({
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json'
      }),
      buildBody: (messages, model, settings, stream = true) => ({
        model: model,
        messages: messages,
        stream: stream,
        temperature: settings.temperature,
        max_tokens: settings.maxTokens
      }),
      parseStreamChunk: (chunk) => {
        if (chunk.startsWith('data: ')) {
          const jsonStr = chunk.replace('data: ', '').trim();
          if (jsonStr === '[DONE]') return { done: true };
          try {
            const parsed = JSON.parse(jsonStr);
            return { 
              content: parsed.choices?.[0]?.delta?.content || '', 
              done: false 
            };
          } catch (e) { return { content: '', done: false }; }
        }
        return { content: '', done: false };
      }
    },

    'OpenRouter': {
      name: 'OpenRouter',
      icon: '🌐',
      color: '#ff6b35',
      endpoint: 'https://openrouter.ai/api/v1/chat/completions',
      models: [
        { id: 'openai/gpt-4o', name: 'GPT-4o (via OpenRouter)', context: 128000, vision: true },
        { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', context: 200000, vision: true },
        { id: 'google/gemini-2.5-pro', name: 'Gemini 2.5 Pro', context: 2000000, vision: true },
        { id: 'meta-llama/llama-3.1-405b-instruct', name: 'Llama 3.1 405B', context: 128000, vision: false },
        { id: 'deepseek/deepseek-r1', name: 'DeepSeek R1', context: 128000, vision: false }
      ],
      compatible: true,
      streamSupported: true,
      headers: (key) => ({
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': window.location.origin,
        'X-Title': 'NEXUS AI Chat'
      }),
      buildBody: (messages, model, settings, stream = true) => ({
        model: model,
        messages: messages,
        stream: stream,
        temperature: settings.temperature,
        max_tokens: settings.maxTokens
      }),
      parseStreamChunk: (chunk) => {
        if (chunk.startsWith('data: ')) {
          const jsonStr = chunk.replace('data: ', '').trim();
          if (jsonStr === '[DONE]') return { done: true };
          try {
            const parsed = JSON.parse(jsonStr);
            return { 
              content: parsed.choices?.[0]?.delta?.content || '', 
              done: false 
            };
          } catch (e) { return { content: '', done: false }; }
        }
        return { content: '', done: false };
      }
    },

    'Anthropic Claude': {
      name: 'Anthropic Claude',
      icon: '🧠',
      color: '#d97757',
      endpoint: 'https://api.anthropic.com/v1/messages',
      models: [
        { id: 'claude-3-5-sonnet-20241022', name: 'Claude 3.5 Sonnet', context: 200000, vision: true },
        { id: 'claude-3-opus-20240229', name: 'Claude 3 Opus', context: 200000, vision: true }
      ],
      compatible: false,
      streamSupported: true,
      headers: (key) => ({
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json'
      }),
      buildBody: (messages, model, settings) => {
        // Convert to Anthropic format
        const systemMsg = messages.find(m => m.role === 'system');
        const userMessages = messages.filter(m => m.role !== 'system');
        
        return {
          model: model,
          max_tokens: settings.maxTokens,
          temperature: settings.temperature,
          system: systemMsg ? systemMsg.content : undefined,
          messages: userMessages.map(m => ({
            role: m.role === 'assistant' ? 'assistant' : 'user',
            content: typeof m.content === 'string' ? m.content : m.content
          }))
        };
      },
      parseStreamChunk: (chunk) => {
        if (chunk.startsWith('data: ')) {
          try {
            const parsed = JSON.parse(chunk.replace('data: ', ''));
            if (parsed.type === 'content_block_delta') {
              return { content: parsed.delta?.text || '', done: false };
            }
            if (parsed.type === 'message_stop') return { done: true };
            return { content: '', done: false };
          } catch (e) { return { content: '', done: false }; }
        }
        return { content: '', done: false };
      }
    },

    'Groq': {
      name: 'Groq',
      icon: '⚡',
      color: '#f55036',
      endpoint: 'https://api.groq.com/openai/v1/chat/completions',
      models: [
        { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B', context: 128000, vision: false },
        { id: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B Instant', context: 128000, vision: false },
        { id: 'gemma2-9b-it', name: 'Gemma 2 9B', context: 8192, vision: false },
        { id: 'deepseek-r1-distill-llama-70b', name: 'DeepSeek R1 Distill', context: 128000, vision: false }
      ],
      compatible: true,
      streamSupported: true,
      headers: (key) => ({
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json'
      }),
      buildBody: (messages, model, settings, stream = true) => ({
        model: model,
        messages: messages,
        stream: stream,
        temperature: settings.temperature,
        max_tokens: settings.maxTokens
      }),
      parseStreamChunk: (chunk) => {
        if (chunk.startsWith('data: ')) {
          const jsonStr = chunk.replace('data: ', '').trim();
          if (jsonStr === '[DONE]') return { done: true };
          try {
            const parsed = JSON.parse(jsonStr);
            return { 
              content: parsed.choices?.[0]?.delta?.content || '', 
              done: false 
            };
          } catch (e) { return { content: '', done: false }; }
        }
        return { content: '', done: false };
      }
    },

    'Mistral AI': {
      name: 'Mistral AI',
      icon: '🌪️',
      color: '#ff7000',
      endpoint: 'https://api.mistral.ai/v1/chat/completions',
      models: [
        { id: 'mistral-large-latest', name: 'Mistral Large', context: 128000, vision: false },
        { id: 'ministral-8b-latest', name: 'Ministral 8B', context: 128000, vision: false }
      ],
      compatible: true,
      streamSupported: true,
      headers: (key) => ({
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json'
      }),
      buildBody: (messages, model, settings, stream = true) => ({
        model: model,
        messages: messages,
        stream: stream,
        temperature: settings.temperature,
        max_tokens: settings.maxTokens
      }),
      parseStreamChunk: (chunk) => {
        if (chunk.startsWith('data: ')) {
          const jsonStr = chunk.replace('data: ', '').trim();
          if (jsonStr === '[DONE]') return { done: true };
          try {
            const parsed = JSON.parse(jsonStr);
            return { content: parsed.choices?.[0]?.delta?.content || '', done: false };
          } catch (e) { return { content: '', done: false }; }
        }
        return { content: '', done: false };
      }
    },

    'Cohere': {
      name: 'Cohere',
      icon: '🔷',
      color: '#395cff',
      endpoint: 'https://api.cohere.com/v1/chat',
      models: [
        { id: 'command-r-plus', name: 'Command R+', context: 128000, vision: false }
      ],
      compatible: false,
      streamSupported: false,
      headers: (key) => ({
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json'
      }),
      buildBody: (messages, model, settings) => {
        const lastUser = messages.filter(m => m.role === 'user').pop();
        const history = messages.filter(m => m.role !== 'system' && m !== lastUser);
        return {
          model: model,
          message: lastUser ? lastUser.content : '',
          chat_history: history.map(m => ({
            role: m.role === 'assistant' ? 'CHATBOT' : 'USER',
            message: m.content
          })),
          temperature: settings.temperature,
          max_tokens: settings.maxTokens
        };
      },
      parseResponse: (data) => data.text || ''
    },

    'Custom API': {
      name: 'Custom API',
      icon: '⚙️',
      color: '#00f3ff',
      endpoint: '', // User provides
      models: [
        { id: 'custom', name: 'Custom Model', context: 8192, vision: false }
      ],
      compatible: true,
      streamSupported: true,
      headers: (key) => ({
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json'
      }),
      buildBody: (messages, model, settings, stream = true) => ({
        model: model,
        messages: messages,
        stream: stream,
        temperature: settings.temperature,
        max_tokens: settings.maxTokens
      }),
      parseStreamChunk: (chunk) => {
        if (chunk.startsWith('data: ')) {
          const jsonStr = chunk.replace('data: ', '').trim();
          if (jsonStr === '[DONE]') return { done: true };
          try {
            const parsed = JSON.parse(jsonStr);
            return { content: parsed.choices?.[0]?.delta?.content || parsed.delta?.content || '', done: false };
          } catch (e) { return { content: '', done: false }; }
        }
        return { content: '', done: false };
      }
    }
  },

  // Get provider config
  getProvider: (name) => {
    return ProviderConfig.providers[name] || ProviderConfig.providers['OpenAI GPT'];
  },

  // Get all provider names
  getProviderNames: () => {
    return Object.keys(ProviderConfig.providers);
  },

  // Get models for provider
  getModels: (providerName) => {
    const provider = ProviderConfig.getProvider(providerName);
    return provider.models || [];
  }
};

// Expose
window.ProviderConfig = ProviderConfig;