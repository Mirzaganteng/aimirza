/**
 * NEXUS AI - Voice Input & Output
 * Web Speech API integration (SpeechRecognition + SpeechSynthesis)
 */

const VoiceManager = {
  recognition: null,
  synthesis: window.speechSynthesis,
  isListening: false,
  currentUtterance: null,
  voices: [],

  init: () => {
    // Initialize Speech Recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      VoiceManager.recognition = new SpeechRecognition();
      VoiceManager.recognition.continuous = false;
      VoiceManager.recognition.interimResults = true;
      VoiceManager.recognition.lang = 'id-ID'; // Default Indonesian

      VoiceManager.recognition.onresult = (event) => {
        let finalTranscript = '';
        let interimTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }

        // Dispatch custom event for UI to handle
        const eventDetail = { final: finalTranscript, interim: interimTranscript };
        document.dispatchEvent(new CustomEvent('voiceResult', { detail: eventDetail }));
      };

      VoiceManager.recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        VoiceManager.isListening = false;
        document.dispatchEvent(new CustomEvent('voiceError', { detail: event.error }));
      };

      VoiceManager.recognition.onend = () => {
        VoiceManager.isListening = false;
        document.dispatchEvent(new CustomEvent('voiceEnd'));
      };
    } else {
      console.warn('SpeechRecognition not supported in this browser.');
    }

    // Load available voices
    if (VoiceManager.synthesis) {
      VoiceManager.loadVoices();
      // Some browsers load voices async
      if (VoiceManager.synthesis.onvoiceschanged !== undefined) {
        VoiceManager.synthesis.onvoiceschanged = VoiceManager.loadVoices;
      }
    }
  },

  loadVoices: () => {
    VoiceManager.voices = VoiceManager.synthesis.getVoices();
  },

  // Start listening
  startListening: (lang = 'id-ID') => {
    if (!VoiceManager.recognition) {
      alert('Browser Anda tidak mendukung Speech Recognition. Gunakan Chrome atau Edge terbaru.');
      return false;
    }

    if (VoiceManager.isListening) {
      VoiceManager.stopListening();
      return false;
    }

    try {
      VoiceManager.recognition.lang = lang;
      VoiceManager.recognition.start();
      VoiceManager.isListening = true;
      document.dispatchEvent(new CustomEvent('voiceStart'));
      return true;
    } catch (err) {
      console.error('Failed to start recognition:', err);
      return false;
    }
  },

  stopListening: () => {
    if (VoiceManager.recognition && VoiceManager.isListening) {
      VoiceManager.recognition.stop();
      VoiceManager.isListening = false;
    }
  },

  // Text to Speech
  speak: (text, options = {}) => {
    if (!VoiceManager.synthesis) {
      console.warn('SpeechSynthesis not supported');
      return false;
    }

    // Cancel any ongoing speech
    VoiceManager.stopSpeaking();

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Options
    utterance.rate = options.rate || 1.0;
    utterance.pitch = options.pitch || 1.0;
    utterance.volume = options.volume || 0.9;
    utterance.lang = options.lang || 'id-ID';

    // Try to find a good voice
    const preferredVoices = ['id-ID', 'en-US', 'en-GB'];
    let selectedVoice = null;

    for (let pref of preferredVoices) {
      selectedVoice = VoiceManager.voices.find(v => v.lang === pref);
      if (selectedVoice) break;
    }

    if (!selectedVoice && VoiceManager.voices.length > 0) {
      selectedVoice = VoiceManager.voices[0];
    }

    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }

    utterance.onend = () => {
      VoiceManager.currentUtterance = null;
      document.dispatchEvent(new CustomEvent('speechEnd'));
    };

    utterance.onerror = (e) => {
      console.error('Speech error:', e);
      VoiceManager.currentUtterance = null;
    };

    VoiceManager.currentUtterance = utterance;
    VoiceManager.synthesis.speak(utterance);
    
    document.dispatchEvent(new CustomEvent('speechStart', { detail: { text } }));
    return true;
  },

  stopSpeaking: () => {
    if (VoiceManager.synthesis) {
      VoiceManager.synthesis.cancel();
      VoiceManager.currentUtterance = null;
    }
  },

  // Get available voices for UI
  getVoices: () => {
    return VoiceManager.voices.map(v => ({
      name: v.name,
      lang: v.lang,
      voiceURI: v.voiceURI
    }));
  },

  // Check support
  isSupported: () => {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition) && !!window.speechSynthesis;
  }
};

// Auto init
if (typeof window !== 'undefined') {
  window.VoiceManager = VoiceManager;
  // Initialize after load
  window.addEventListener('load', () => {
    VoiceManager.init();
  });
}