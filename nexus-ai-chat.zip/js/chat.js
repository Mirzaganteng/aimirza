/**
 * NEXUS AI - Main Chat Logic
 * Core chat functionality, message rendering, streaming, agents, file handling
 */

const ChatApp = {
  currentChat: null,
  attachedFile: null,
  isGenerating: false,
  currentAgentMode: 'default',

  // Initialize the dashboard
  init: () => {
    console.log('%c[NEXUS AI] Initializing Chat Dashboard...', 'color:#00f3ff');

    // Check login state
    const apiKeys = StorageManager.getApiKeys();
    if (Object.keys(apiKeys).length === 0) {
      window.location.href = 'login.html';
      return;
    }

    // Load settings
    SettingsManager.init();

    // Set initial provider/model
    const currentProvider = StorageManager.getCurrentProvider();
    const currentModel = StorageManager.getCurrentModel();
    ChatApp.currentAgentMode = StorageManager.getAgentMode();

    // Render initial UI
    ChatApp.renderSidebar();
    ChatApp.setupEventListeners();
    ChatApp.updateModelSelector();
    ChatApp.updateAgentPills();

    // Load or create chat
    const currentChatId = StorageManager.getCurrentChatId();
    if (currentChatId) {
      ChatApp.loadChat(currentChatId);
    } else {
      const chats = StorageManager.getChats();
      if (chats.length > 0) {
        ChatApp.loadChat(chats[0].id);
      } else {
        ChatApp.createNewChat();
      }
    }

    // Welcome toast
    setTimeout(() => {
      if (window.showToast) {
        window.showToast('Selamat datang di NEXUS AI! Pilih model dan mulai chat.', 'info', 3000);
      }
    }, 1200);

    // Initialize voice if supported
    if (VoiceManager.isSupported && VoiceManager.isSupported()) {
      console.log('%c[Voice] Web Speech API ready', 'color:#00ff9d');
    }

    // Make some functions global for debugging
    window.NEXUS = ChatApp;
  },

  // Setup all event listeners
  setupEventListeners: () => {
    // New Chat
    const newChatBtn = document.getElementById('new-chat-btn');
    if (newChatBtn) newChatBtn.onclick = () => ChatApp.createNewChat();

    // Send message
    const sendBtn = document.getElementById('send-btn');
    const input = document.getElementById('message-input');

    if (sendBtn) {
      sendBtn.onclick = () => ChatApp.sendCurrentMessage();
    }

    if (input) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          ChatApp.sendCurrentMessage();
        }
      });

      // Auto grow textarea
      input.addEventListener('input', () => {
        input.style.height = 'auto';
        input.style.height = Math.min(input.scrollHeight, 180) + 'px';
      });
    }

    // Voice input button
    const micBtn = document.getElementById('mic-btn');
    if (micBtn) {
      micBtn.onclick = () => {
        if (VoiceManager.isListening) {
          VoiceManager.stopListening();
          micBtn.style.background = '';
        } else {
          const started = VoiceManager.startListening('id-ID');
          if (started) {
            micBtn.style.background = 'rgba(0, 243, 255, 0.2)';
            micBtn.style.borderColor = 'var(--accent-blue)';
          }
        }
      };
    }

    // Voice result listener
    document.addEventListener('voiceResult', (e) => {
      const { final, interim } = e.detail;
      if (input) {
        if (final) {
          input.value = final;
          // Auto send after voice input
          setTimeout(() => {
            if (input.value.trim()) ChatApp.sendCurrentMessage();
          }, 400);
        } else if (interim) {
          input.placeholder = interim;
        }
      }
    });

    document.addEventListener('voiceEnd', () => {
      if (micBtn) {
        micBtn.style.background = '';
        micBtn.style.borderColor = '';
      }
      if (input) input.placeholder = 'Ketik pesan atau gunakan voice input...';
    });

    // File upload
    const uploadBtn = document.getElementById('upload-btn');
    const fileInput = document.getElementById('file-input');
    
    if (uploadBtn && fileInput) {
      uploadBtn.onclick = () => fileInput.click();
      
      fileInput.onchange = async (e) => {
        if (e.target.files.length > 0) {
          await ChatApp.handleFileUpload(e.target.files[0]);
        }
        fileInput.value = '';
      };
    }

    // Stop generation
    const stopBtn = document.getElementById('stop-btn');
    if (stopBtn) {
      stopBtn.onclick = () => {
        APIHandler.stopGeneration();
        ChatApp.isGenerating = false;
        UIManager.setSendButtonLoading(false);
        if (window.showToast) window.showToast('Generasi dihentikan.', 'warning');
      };
    }

    // Model selector click -> open model modal
    const modelSelector = document.getElementById('model-selector');
    if (modelSelector) {
      modelSelector.onclick = () => ChatApp.showModelModal();
    }

    // Sidebar menu items
    document.querySelectorAll('.sidebar-menu-item').forEach(item => {
      item.onclick = () => {
        const action = item.dataset.action;
        ChatApp.handleSidebarAction(action);
      };
    });

    // Agent pills
    document.querySelectorAll('.agent-pill').forEach(pill => {
      pill.onclick = () => {
        const mode = pill.dataset.mode;
        ChatApp.setAgentMode(mode);
      };
    });

    // Theme toggle
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) themeToggle.onclick = UIManager.toggleTheme;

    // Settings button
    const settingsBtn = document.getElementById('settings-btn');
    if (settingsBtn) {
      settingsBtn.onclick = () => SettingsManager.openSettingsModal();
    }

    // Save settings button in modal
    const saveSettingsBtn = document.getElementById('save-settings-btn');
    if (saveSettingsBtn) {
      saveSettingsBtn.onclick = () => SettingsManager.saveSettings();
    }

    // Reset settings
    const resetSettingsBtn = document.getElementById('reset-settings-btn');
    if (resetSettingsBtn) {
      resetSettingsBtn.onclick = () => SettingsManager.resetToDefaults();
    }

    // Close modals
    document.querySelectorAll('.modal .close-btn').forEach(btn => {
      btn.onclick = () => btn.closest('.modal').classList.remove('active');
    });

    // API Manager button
    const apiManagerBtn = document.getElementById('api-manager-btn');
    if (apiManagerBtn) apiManagerBtn.onclick = () => ChatApp.showApiManagerModal();

    // Export buttons
    const exportTxt = document.getElementById('export-txt');
    if (exportTxt) exportTxt.onclick = () => {
      if (ChatApp.currentChat) ExportManager.exportToTXT(ChatApp.currentChat);
    };

    const exportPdf = document.getElementById('export-pdf');
    if (exportPdf) exportPdf.onclick = () => {
      if (ChatApp.currentChat) ExportManager.exportToPDF(ChatApp.currentChat);
    };

    const exportJson = document.getElementById('export-json');
    if (exportJson) exportJson.onclick = () => {
      if (ChatApp.currentChat) ExportManager.exportToJSON(ChatApp.currentChat);
    };

    // Import
    const importBtn = document.getElementById('import-chat-btn');
    const importInput = document.getElementById('import-input');
    if (importBtn && importInput) {
      importBtn.onclick = () => importInput.click();
      importInput.onchange = (e) => {
        if (e.target.files[0]) {
          ImportManager.importFromFile(e.target.files[0], (newChat) => {
            ChatApp.renderSidebar();
            ChatApp.loadChat(newChat.id);
          });
        }
      };
    }

    // Window resize for responsive
    window.addEventListener('resize', Utils.debounce(() => {
      // Could add more responsive logic
    }, 200));
  },

  // Handle sidebar menu actions
  handleSidebarAction: (action) => {
    switch (action) {
      case 'new-chat':
        ChatApp.createNewChat();
        break;
      case 'settings':
        SettingsManager.openSettingsModal();
        break;
      case 'api-manager':
        ChatApp.showApiManagerModal();
        break;
      case 'theme':
        UIManager.toggleTheme();
        break;
      case 'about':
        ChatApp.showAboutModal();
        break;
      case 'agents':
        document.getElementById('agent-selector')?.scrollIntoView({ behavior: 'smooth' });
        break;
      default:
        if (window.showToast) window.showToast('Fitur dalam pengembangan', 'info');
    }
  },

  // Create new chat
  createNewChat: () => {
    const newChat = StorageManager.createNewChat('Chat Baru');
    ChatApp.currentChat = newChat;
    ChatApp.renderMessages();
    ChatApp.renderSidebar();
    
    // Focus input
    setTimeout(() => {
      const input = document.getElementById('message-input');
      if (input) input.focus();
    }, 100);
  },

  // Load existing chat
  loadChat: (chatId) => {
    const chat = StorageManager.getChatById(chatId);
    if (!chat) {
      console.warn('Chat not found:', chatId);
      ChatApp.createNewChat();
      return;
    }

    ChatApp.currentChat = chat;
    StorageManager.setCurrentChatId(chatId);

    // Restore provider/model if different
    if (chat.provider) StorageManager.setCurrentProvider(chat.provider);
    if (chat.model) StorageManager.setCurrentModel(chat.model);
    if (chat.agentMode) {
      ChatApp.currentAgentMode = chat.agentMode;
      StorageManager.setAgentMode(chat.agentMode);
    }

    ChatApp.renderMessages();
    ChatApp.renderSidebar();
    ChatApp.updateModelSelector();
    ChatApp.updateAgentPills();
  },

  // Render all messages in current chat
  renderMessages: () => {
    const container = document.getElementById('messages-container');
    const welcome = document.getElementById('welcome-screen');
    
    if (!container) return;

    container.innerHTML = '';

    if (!ChatApp.currentChat || !ChatApp.currentChat.messages || ChatApp.currentChat.messages.length === 0) {
      if (welcome) welcome.style.display = 'flex';
      container.style.display = 'none';
      return;
    }

    if (welcome) welcome.style.display = 'none';
    container.style.display = 'block';

    ChatApp.currentChat.messages.forEach(msg => {
      ChatApp.appendMessageToDOM(msg, false);
    });

    // Scroll to bottom
    container.scrollTop = container.scrollHeight;
  },

  // Append single message to DOM (with optional streaming)
  appendMessageToDOM: (message, isStreaming = false) => {
    const container = document.getElementById('messages-container');
    if (!container) return;

    const welcome = document.getElementById('welcome-screen');
    if (welcome) welcome.style.display = 'none';
    container.style.display = 'block';

    const msgEl = document.createElement('div');
    msgEl.className = `message ${message.role}`;
    msgEl.dataset.messageId = message.id || '';

    let contentHTML = '';

    if (message.role === 'user') {
      contentHTML = `<div class="message-content">${Utils.escapeHtml(message.content).replace(/\n/g, '<br>')}</div>`;
    } else {
      // Assistant - will be enhanced with markdown later
      contentHTML = `<div class="message-content streaming-text">${Utils.escapeHtml(message.content || '').replace(/\n/g, '<br>')}</div>`;
    }

    msgEl.innerHTML = `
      ${contentHTML}
      <div class="message-toolbar">
        <button class="message-action copy-btn" title="Salin">📋</button>
        ${message.role === 'assistant' ? `
          <button class="message-action regenerate-btn" title="Regenerate">🔄</button>
          <button class="message-action tts-btn" title="Baca suara">🔊</button>
        ` : ''}
        <button class="message-action edit-btn" title="Edit">✏️</button>
        <button class="message-action delete-btn" title="Hapus">🗑️</button>
      </div>
    `;

    container.appendChild(msgEl);

    // Enhance assistant messages with markdown + code highlight + latex
    if (message.role === 'assistant' && message.content) {
      ChatApp.enhanceMessageContent(msgEl, message.content);
    }

    // Toolbar actions
    ChatApp.attachMessageToolbarListeners(msgEl, message);

    if (!isStreaming) {
      container.scrollTop = container.scrollHeight;
    }

    return msgEl;
  },

  // Enhance message with markdown, syntax highlight, KaTeX
  enhanceMessageContent: (msgEl, rawContent) => {
    const contentDiv = msgEl.querySelector('.message-content');
    if (!contentDiv) return;

    // Use marked if available, else basic
    let html = rawContent;

    if (typeof marked !== 'undefined') {
      try {
        html = marked.parse(rawContent, {
          breaks: true,
          gfm: true,
          highlight: function(code, lang) {
            if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) {
              try {
                return hljs.highlight(code, { language: lang }).value;
              } catch (_) {}
            }
            return code;
          }
        });
      } catch (e) {
        html = Utils.basicMarkdown(rawContent);
      }
    } else {
      html = Utils.basicMarkdown(rawContent);
    }

    contentDiv.innerHTML = html;

    // Apply syntax highlighting to code blocks
    if (typeof hljs !== 'undefined') {
      contentDiv.querySelectorAll('pre code').forEach(block => {
        hljs.highlightElement(block);
      });
    }

    // Render LaTeX with KaTeX if available
    if (typeof renderMathInElement !== 'undefined' || typeof katex !== 'undefined') {
      try {
        if (typeof renderMathInElement !== 'undefined') {
          renderMathInElement(contentDiv, {
            delimiters: [
              { left: '$$', right: '$$', display: true },
              { left: '$', right: '$', display: false },
              { left: '\\(', right: '\\)', display: false },
              { left: '\\[', right: '\\]', display: true }
            ],
            throwOnError: false
          });
        }
      } catch (e) {}
    }

    // Add copy buttons to code blocks
    contentDiv.querySelectorAll('pre').forEach(pre => {
      const copyBtn = document.createElement('button');
      copyBtn.className = 'copy-code-btn';
      copyBtn.textContent = 'Copy';
      copyBtn.onclick = async () => {
        const code = pre.querySelector('code').innerText;
        const success = await Utils.copyToClipboard(code);
        copyBtn.textContent = success ? 'Copied!' : 'Error';
        setTimeout(() => copyBtn.textContent = 'Copy', 1600);
      };
      pre.appendChild(copyBtn);
    });
  },

  // Attach toolbar button listeners
  attachMessageToolbarListeners: (msgEl, message) => {
    const copyBtn = msgEl.querySelector('.copy-btn');
    if (copyBtn) {
      copyBtn.onclick = async () => {
        const success = await Utils.copyToClipboard(message.content);
        if (window.showToast) {
          window.showToast(success ? 'Pesan disalin ke clipboard' : 'Gagal menyalin', success ? 'success' : 'error');
        }
      };
    }

    const deleteBtn = msgEl.querySelector('.delete-btn');
    if (deleteBtn) {
      deleteBtn.onclick = () => {
        if (confirm('Hapus pesan ini?')) {
          ChatApp.deleteMessage(message.id);
        }
      };
    }

    const editBtn = msgEl.querySelector('.edit-btn');
    if (editBtn) {
      editBtn.onclick = () => ChatApp.editMessage(message, msgEl);
    }

    const regenBtn = msgEl.querySelector('.regenerate-btn');
    if (regenBtn) {
      regenBtn.onclick = () => ChatApp.regenerateLastResponse();
    }

    const ttsBtn = msgEl.querySelector('.tts-btn');
    if (ttsBtn) {
      ttsBtn.onclick = () => {
        if (VoiceManager.synthesis) {
          VoiceManager.speak(message.content, { lang: 'id-ID' });
        } else {
          if (window.showToast) window.showToast('TTS tidak didukung browser ini', 'warning');
        }
      };
    }
  },

  // Send the current input message
  sendCurrentMessage: async () => {
    const input = document.getElementById('message-input');
    if (!input || ChatApp.isGenerating) return;

    const text = input.value.trim();
    if (!text && !ChatApp.attachedFile) return;

    const settings = StorageManager.getSettings();
    const provider = StorageManager.getCurrentProvider();
    const model = StorageManager.getCurrentModel();

    // Create user message
    const userMessage = {
      role: 'user',
      content: text || (ChatApp.attachedFile ? `[File: ${ChatApp.attachedFile.name}]` : ''),
      timestamp: Date.now()
    };

    // Add to current chat
    if (!ChatApp.currentChat) ChatApp.createNewChat();

    StorageManager.addMessageToChat(ChatApp.currentChat.id, userMessage);
    ChatApp.currentChat.messages.push(userMessage);

    // Render user message
    ChatApp.appendMessageToDOM(userMessage);

    // Clear input
    input.value = '';
    input.style.height = 'auto';

    // Show file preview removal
    ChatApp.clearFilePreview();

    // Prepare for AI response
    ChatApp.isGenerating = true;
    UIManager.setSendButtonLoading(true);

    const assistantMsgEl = ChatApp.appendMessageToDOM({
      role: 'assistant',
      content: '',
      timestamp: Date.now()
    }, true);

    const contentDiv = assistantMsgEl.querySelector('.message-content');

    let fullResponse = '';

    // Build messages for API
    const apiMessages = APIHandler.buildMessages(
      ChatApp.currentChat.messages.slice(0, -1), // history without the last user msg
      text,
      ChatApp.attachedFile,
      settings.systemPrompt,
      settings.customInstructions,
      ChatApp.currentAgentMode
    );

    // Stream handler
    const onChunk = (chunk) => {
      fullResponse += chunk;
      if (contentDiv) {
        contentDiv.innerHTML = Utils.escapeHtml(fullResponse).replace(/\n/g, '<br>');
      }
      // Auto scroll
      const container = document.getElementById('messages-container');
      if (container) container.scrollTop = container.scrollHeight;
    };

    const onComplete = (finalContent) => {
      ChatApp.isGenerating = false;
      UIManager.setSendButtonLoading(false);

      if (finalContent && contentDiv) {
        // Final enhance
        ChatApp.enhanceMessageContent(assistantMsgEl, finalContent);
        
        // Save to storage
        const assistantMessage = {
          role: 'assistant',
          content: finalContent,
          timestamp: Date.now(),
          model: model,
          provider: provider
        };
        
        StorageManager.addMessageToChat(ChatApp.currentChat.id, assistantMessage);
        ChatApp.currentChat.messages.push(assistantMessage);

        // Auto speak if enabled
        if (settings.autoSpeak && VoiceManager.speak) {
          VoiceManager.speak(finalContent.substring(0, 800), { lang: 'id-ID' });
        }
      }

      // Clear attached file
      ChatApp.attachedFile = null;

      // Update sidebar (title may have changed)
      ChatApp.renderSidebar();
    };

    const onError = (error) => {
      ChatApp.isGenerating = false;
      UIManager.setSendButtonLoading(false);
      
      if (contentDiv) {
        contentDiv.innerHTML = `<span style="color:#ff3b5c">Error: ${error.message}</span>`;
      }
      
      if (window.showToast) {
        window.showToast('Gagal mendapatkan respons: ' + error.message, 'error');
      }
    };

    // Call API
    try {
      await APIHandler.sendMessage(
        apiMessages,
        provider,
        model,
        settings,
        onChunk,
        onComplete,
        onError
      );
    } catch (err) {
      onError(err);
    }
  },

  // Handle file upload
  handleFileUpload: async (file) => {
    try {
      if (window.showToast) window.showToast('Memproses file...', 'info', 1500);
      
      const processed = await APIHandler.processFile(file);
      ChatApp.attachedFile = processed;

      // Show preview
      ChatApp.showFilePreview(processed);

      if (window.showToast) {
        window.showToast(`File "${processed.name}" siap dilampirkan`, 'success');
      }
    } catch (err) {
      if (window.showToast) window.showToast('Gagal memproses file: ' + err.message, 'error');
    }
  },

  showFilePreview: (fileData) => {
    const container = document.getElementById('file-preview-container');
    if (!container) return;

    container.innerHTML = `
      <div class="file-preview">
        <div class="file-info">
          <strong>${fileData.name}</strong> 
          <span style="color:var(--text-muted)">(${Utils.formatFileSize(fileData.size)})</span>
          ${fileData.type === 'pdf' ? ` • ${fileData.pages || '?'} halaman` : ''}
        </div>
        <span class="remove-file" style="cursor:pointer; font-size:20px; color:#ff3b5c">×</span>
      </div>
    `;

    container.querySelector('.remove-file').onclick = () => {
      ChatApp.clearFilePreview();
    };

    container.style.display = 'block';
  },

  clearFilePreview: () => {
    const container = document.getElementById('file-preview-container');
    if (container) {
      container.innerHTML = '';
      container.style.display = 'none';
    }
    ChatApp.attachedFile = null;
  },

  // Delete a message
  deleteMessage: (messageId) => {
    if (!ChatApp.currentChat) return;

    ChatApp.currentChat.messages = ChatApp.currentChat.messages.filter(m => m.id !== messageId);
    StorageManager.updateChat(ChatApp.currentChat.id, { messages: ChatApp.currentChat.messages });
    
    ChatApp.renderMessages();
  },

  // Edit message (simple prompt for now)
  editMessage: (message, msgEl) => {
    const newContent = prompt('Edit pesan:', message.content);
    if (newContent === null || newContent === message.content) return;

    message.content = newContent;
    
    // Update storage
    const chatIndex = StorageManager.getChats().findIndex(c => c.id === ChatApp.currentChat.id);
    if (chatIndex !== -1) {
      const msgIndex = StorageManager.getChats()[chatIndex].messages.findIndex(m => m.id === message.id);
      if (msgIndex !== -1) {
        StorageManager.getChats()[chatIndex].messages[msgIndex].content = newContent;
        StorageManager.saveChats(StorageManager.getChats());
      }
    }

    // Re-render
    ChatApp.renderMessages();
  },

  // Regenerate last AI response
  regenerateLastResponse: async () => {
    if (!ChatApp.currentChat || ChatApp.currentChat.messages.length < 2) return;

    // Remove last assistant message
    const lastMsg = ChatApp.currentChat.messages[ChatApp.currentChat.messages.length - 1];
    if (lastMsg.role !== 'assistant') return;

    ChatApp.currentChat.messages.pop();
    StorageManager.updateChat(ChatApp.currentChat.id, { messages: ChatApp.currentChat.messages });

    ChatApp.renderMessages();

    // Re-send the last user message
    setTimeout(() => {
      const lastUser = ChatApp.currentChat.messages[ChatApp.currentChat.messages.length - 1];
      if (lastUser && lastUser.role === 'user') {
        // Simulate clicking send with same content
        const input = document.getElementById('message-input');
        if (input) {
          input.value = lastUser.content;
          ChatApp.sendCurrentMessage();
        }
      }
    }, 300);
  },

  // Update model selector UI
  updateModelSelector: () => {
    const provider = StorageManager.getCurrentProvider();
    const model = StorageManager.getCurrentModel();
    UIManager.updateModelDisplay(provider, model);
  },

  // Show model selection modal
  showModelModal: () => {
    const modal = document.getElementById('model-modal');
    if (!modal) {
      // Create modal dynamically if not exists
      ChatApp.createModelModal();
      return;
    }
    modal.classList.add('active');
  },

  createModelModal: () => {
    const modal = document.createElement('div');
    modal.id = 'model-modal';
    modal.className = 'modal';

    const providers = ProviderConfig.getProviderNames();
    let html = `
      <div class="modal-content glass">
        <div class="modal-header">
          <h3>Pilih Provider & Model</h3>
          <button class="close-btn btn-icon">×</button>
        </div>
        <div class="modal-body">
    `;

    providers.forEach(prov => {
      const pConfig = ProviderConfig.getProvider(prov);
      html += `<div style="margin-bottom: 20px;">
        <div style="font-weight:600; margin-bottom:8px; display:flex; align-items:center; gap:8px;">
          <span style="color:${pConfig.color}">${pConfig.icon}</span> ${prov}
        </div>`;

      pConfig.models.forEach(m => {
        html += `
          <div class="model-option" data-provider="${prov}" data-model="${m.id}" 
               style="padding:10px 14px; margin:4px 0; background:var(--bg-tertiary); border-radius:10px; cursor:pointer; display:flex; justify-content:space-between; align-items:center;">
            <div>
              <div style="font-weight:500">${m.name}</div>
              <div style="font-size:12px; color:var(--text-muted)">Context: ${m.context.toLocaleString()} tokens ${m.vision ? '• Vision' : ''}</div>
            </div>
            <button class="btn btn-neon" style="padding:6px 14px; font-size:12px">Pilih</button>
          </div>`;
      });
      html += `</div>`;
    });

    html += `</div></div>`;
    modal.innerHTML = html;
    document.body.appendChild(modal);

    // Event listeners
    modal.querySelector('.close-btn').onclick = () => modal.classList.remove('active');

    modal.querySelectorAll('.model-option').forEach(option => {
      option.onclick = () => {
        const provider = option.dataset.provider;
        const model = option.dataset.model;

        StorageManager.setCurrentProvider(provider);
        StorageManager.setCurrentModel(model);

        if (ChatApp.currentChat) {
          StorageManager.updateChat(ChatApp.currentChat.id, { provider, model });
          ChatApp.currentChat.provider = provider;
          ChatApp.currentChat.model = model;
        }

        ChatApp.updateModelSelector();
        modal.classList.remove('active');

        if (window.showToast) window.showToast(`Model diubah ke ${model}`, 'success');
      };
    });

    modal.classList.add('active');
  },

  // Update agent pills UI
  updateAgentPills: () => {
    document.querySelectorAll('.agent-pill').forEach(pill => {
      pill.classList.toggle('active', pill.dataset.mode === ChatApp.currentAgentMode);
    });
  },

  // Set agent mode
  setAgentMode: (mode) => {
    ChatApp.currentAgentMode = mode;
    StorageManager.setAgentMode(mode);

    if (ChatApp.currentChat) {
      StorageManager.updateChat(ChatApp.currentChat.id, { agentMode: mode });
    }

    ChatApp.updateAgentPills();

    const modeNames = {
      'default': 'Mode Normal',
      'research': 'Research Agent',
      'coding': 'Coding Agent',
      'writing': 'Writing Agent',
      'translation': 'Translation Agent',
      'summarizer': 'Summarizer Agent',
      'websearch': 'Web Search Agent'
    };

    if (window.showToast) {
      window.showToast(`Agent diubah ke: ${modeNames[mode] || mode}`, 'info');
    }
  },

  // Render sidebar chat list + menu
  renderSidebar: () => {
    const chats = StorageManager.getChats();
    const currentId = StorageManager.getCurrentChatId();

    UIManager.renderChatList(chats, currentId, 
      (chatId) => ChatApp.loadChat(chatId),
      (chatId) => {
        StorageManager.deleteChat(chatId);
        ChatApp.renderSidebar();
        if (ChatApp.currentChat && ChatApp.currentChat.id === chatId) {
          const remaining = StorageManager.getChats();
          if (remaining.length > 0) {
            ChatApp.loadChat(remaining[0].id);
          } else {
            ChatApp.createNewChat();
          }
        }
      }
    );
  },

  // Show API Manager Modal
  showApiManagerModal: () => {
    const modal = document.getElementById('api-manager-modal');
    if (!modal) {
      ChatApp.createApiManagerModal();
      return;
    }
    modal.classList.add('active');
    ChatApp.refreshApiKeyList();
  },

  createApiManagerModal: () => {
    const modal = document.createElement('div');
    modal.id = 'api-manager-modal';
    modal.className = 'modal';

    modal.innerHTML = `
      <div class="modal-content glass" style="max-width:620px">
        <div class="modal-header">
          <h3>API Key Manager</h3>
          <button class="close-btn btn-icon">×</button>
        </div>
        <div class="modal-body">
          <p style="color:var(--text-secondary); font-size:14px; margin-bottom:20px">
            API Key disimpan secara lokal di browser Anda. Tidak pernah dikirim ke server NEXUS.
          </p>
          
          <div style="display:flex; gap:12px; margin-bottom:20px">
            <select id="api-provider-select" class="select" style="flex:1">
              ${ProviderConfig.getProviderNames().map(p => `<option value="${p}">${p}</option>`).join('')}
            </select>
            <input id="api-key-input" class="input" placeholder="Masukkan API Key..." style="flex:2; font-family:monospace">
            <button id="add-api-key-btn" class="btn btn-primary">Tambah</button>
          </div>

          <div id="api-key-list" class="api-key-list"></div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    modal.querySelector('.close-btn').onclick = () => modal.classList.remove('active');

    // Add key
    modal.querySelector('#add-api-key-btn').onclick = () => {
      const provider = modal.querySelector('#api-provider-select').value;
      const key = modal.querySelector('#api-key-input').value.trim();

      if (!key) {
        if (window.showToast) window.showToast('Masukkan API Key', 'warning');
        return;
      }

      if (!Utils.isValidApiKey(key, provider) && provider !== 'Custom API') {
        if (!confirm('Format API Key sepertinya tidak standar. Lanjutkan?')) return;
      }

      StorageManager.saveApiKey(provider, key);
      modal.querySelector('#api-key-input').value = '';
      ChatApp.refreshApiKeyList();
      if (window.showToast) window.showToast(`API Key untuk ${provider} disimpan`, 'success');
    };

    modal.classList.add('active');
    ChatApp.refreshApiKeyList();
  },

  refreshApiKeyList: () => {
    const listContainer = document.getElementById('api-key-list');
    if (!listContainer) return;

    const keys = StorageManager.getApiKeys();
    listContainer.innerHTML = '';

    if (Object.keys(keys).length === 0) {
      listContainer.innerHTML = `<p style="color:var(--text-muted)">Belum ada API Key tersimpan.</p>`;
      return;
    }

    Object.entries(keys).forEach(([provider, data]) => {
      const item = document.createElement('div');
      item.className = 'api-key-item';
      item.innerHTML = `
        <div class="key-info">
          <div class="key-provider">${provider}</div>
          <div class="key-value">${data.key.substring(0, 12)}••••••••</div>
        </div>
        <div class="key-actions">
          <button class="btn btn-secondary" style="padding:6px 12px; font-size:12px" data-action="use">Gunakan</button>
          <button class="btn btn-danger" style="padding:6px 12px; font-size:12px" data-action="delete">Hapus</button>
        </div>
      `;

      item.querySelector('[data-action="use"]').onclick = () => {
        StorageManager.setCurrentProvider(provider);
        ChatApp.updateModelSelector();
        document.getElementById('api-manager-modal').classList.remove('active');
        if (window.showToast) window.showToast(`Provider diubah ke ${provider}`, 'success');
      };

      item.querySelector('[data-action="delete"]').onclick = () => {
        if (confirm(`Hapus API Key untuk ${provider}?`)) {
          StorageManager.deleteApiKey(provider);
          ChatApp.refreshApiKeyList();
        }
      };

      listContainer.appendChild(item);
    });
  },

  // About modal
  showAboutModal: () => {
    const modal = document.createElement('div');
    modal.className = 'modal active';
    modal.innerHTML = `
      <div class="modal-content glass" style="max-width:480px; text-align:center">
        <div style="padding:32px 24px">
          <div class="logo" style="justify-content:center; margin-bottom:16px">
            <div class="logo-icon">N</div>
            <span class="logo-text" style="font-size:28px">NEXUS AI</span>
          </div>
          <p style="color:var(--text-secondary)">Modern AI Chat Interface</p>
          <p style="margin:20px 0; font-size:14px">Versi 1.0 • Dibuat dengan ❤️ menggunakan Vanilla HTML, CSS & JavaScript</p>
          
          <div style="display:flex; gap:12px; justify-content:center; margin-top:24px">
            <button class="btn btn-secondary close-about">Tutup</button>
            <button class="btn btn-primary" onclick="window.location.reload()">Reload App</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.querySelector('.close-about').onclick = () => modal.remove();
  }
};

// Boot the app when DOM ready
document.addEventListener('DOMContentLoaded', () => {
  ChatApp.init();
});

// Also expose
window.ChatApp = ChatApp;