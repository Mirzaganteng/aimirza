/**
 * NEXUS AI - UI Manager
 * Toast notifications, modals, responsive behavior, theme toggle
 */

const UIManager = {
  toastContainer: null,

  init: () => {
    // Create toast container
    UIManager.toastContainer = document.createElement('div');
    UIManager.toastContainer.className = 'toast-container';
    document.body.appendChild(UIManager.toastContainer);

    // Offline detection
    window.addEventListener('online', () => UIManager.updateOnlineStatus(true));
    window.addEventListener('offline', () => UIManager.updateOnlineStatus(false));
    
    // Initial status
    UIManager.updateOnlineStatus(navigator.onLine);

    // Theme initialization
    const savedTheme = StorageManager.getTheme();
    if (savedTheme === 'light') {
      document.body.classList.add('light');
    }

    // Close modals on outside click
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
      }
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      if (e.key === '/' && document.activeElement.tagName === 'BODY') {
        e.preventDefault();
        const input = document.getElementById('message-input');
        if (input) input.focus();
      }
      
      if (e.metaKey && e.key === 'k') {
        e.preventDefault();
        const newChatBtn = document.getElementById('new-chat-btn');
        if (newChatBtn) newChatBtn.click();
      }
    });
  },

  // Toast Notification
  showToast: (message, type = 'info', duration = 4500) => {
    if (!UIManager.toastContainer) UIManager.init();

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    const icons = {
      success: '✅',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️'
    };

    toast.innerHTML = `
      <div style="display:flex; align-items:center; gap:12px; width:100%">
        <span style="font-size:20px">${icons[type] || 'ℹ️'}</span>
        <div style="flex:1; font-size:14.5px; line-height:1.4">${message}</div>
        <button class="toast-close" aria-label="Close">×</button>
      </div>
    `;

    UIManager.toastContainer.appendChild(toast);

    // Close button
    toast.querySelector('.toast-close').onclick = () => {
      toast.classList.add('exiting');
      setTimeout(() => toast.remove(), 200);
    };

    // Auto dismiss
    setTimeout(() => {
      if (toast.parentNode) {
        toast.classList.add('exiting');
        setTimeout(() => {
          if (toast.parentNode) toast.parentNode.removeChild(toast);
        }, 220);
      }
    }, duration);
  },

  updateOnlineStatus: (isOnline) => {
    let banner = document.getElementById('offline-banner');
    
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'offline-banner';
      banner.className = 'offline-banner';
      banner.innerHTML = '⚠️ Anda sedang offline. Beberapa fitur mungkin tidak tersedia.';
      const dashboard = document.querySelector('.dashboard');
      if (dashboard) dashboard.prepend(banner);
    }

    if (!isOnline) {
      banner.classList.add('show');
    } else {
      banner.classList.remove('show');
    }
  },

  // Toggle theme
  toggleTheme: () => {
    const isLight = document.body.classList.toggle('light');
    const newTheme = isLight ? 'light' : 'dark';
    StorageManager.setTheme(newTheme);
    
    UIManager.showToast(`Tema diubah ke ${newTheme === 'light' ? 'Light' : 'Dark'}`, 'info', 2000);
  },

  // Show/Hide sidebar on mobile
  toggleSidebar: () => {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
      sidebar.classList.toggle('collapsed');
    }
  },

  // Render chat list in sidebar
  renderChatList: (chats, currentChatId, onSelect, onDelete) => {
    const container = document.getElementById('chat-list');
    if (!container) return;

    container.innerHTML = '';

    if (!chats || chats.length === 0) {
      container.innerHTML = `
        <div style="padding: 20px; text-align: center; color: var(--text-muted); font-size: 13px;">
          Belum ada riwayat chat.<br>
          Mulai chat baru!
        </div>
      `;
      return;
    }

    chats.forEach(chat => {
      const item = document.createElement('div');
      item.className = `chat-item ${chat.id === currentChatId ? 'active' : ''}`;
      
      item.innerHTML = `
        <div class="chat-info">
          <div class="chat-title">${Utils.escapeHtml(chat.title || 'Chat Baru')}</div>
          <div class="chat-meta">${Utils.formatTime(chat.updatedAt)} • ${chat.model || ''}</div>
        </div>
        <div class="chat-actions">
          <button class="delete-chat-btn" title="Hapus chat">🗑️</button>
        </div>
      `;

      // Click to load
      item.onclick = (e) => {
        if (!e.target.closest('.chat-actions')) {
          onSelect(chat.id);
        }
      };

      // Delete
      const delBtn = item.querySelector('.delete-chat-btn');
      delBtn.onclick = (e) => {
        e.stopImmediatePropagation();
        if (confirm('Hapus chat ini?')) {
          onDelete(chat.id);
        }
      };

      container.appendChild(item);
    });
  },

  // Update model selector display
  updateModelDisplay: (provider, model) => {
    const selector = document.getElementById('model-selector');
    if (!selector) return;

    const providerInfo = ProviderConfig.getProvider(provider);
    
    selector.innerHTML = `
      <div class="model-info">
        <div class="model-name">${model}</div>
        <div class="provider-name">${providerInfo.icon} ${provider}</div>
      </div>
    `;
  },

  // Show loading in send button
  setSendButtonLoading: (isLoading) => {
    const btn = document.getElementById('send-btn');
    if (!btn) return;

    if (isLoading) {
      btn.innerHTML = '<div class="spinner"></div>';
      btn.disabled = true;
    } else {
      btn.innerHTML = '➤';
      btn.disabled = false;
    }
  }
};

// Make showToast globally available
window.showToast = UIManager.showToast;

window.UIManager = UIManager;