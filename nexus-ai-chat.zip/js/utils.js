/**
 * NEXUS AI - Utility Functions
 * Common helpers, formatters, validators
 */

const Utils = {
  // Generate unique ID
  generateId: () => {
    return 'chat_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
  },

  // Format timestamp
  formatTime: (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Baru saja';
    if (diffMins < 60) return `${diffMins} menit lalu`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)} jam lalu`;
    
    return date.toLocaleDateString('id-ID', { 
      day: 'numeric', 
      month: 'short', 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  },

  // Debounce function
  debounce: (func, wait) => {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  // Copy text to clipboard
  async copyToClipboard(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      } else {
        // Fallback
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        const success = document.execCommand('copy');
        textArea.remove();
        return success;
      }
    } catch (err) {
      console.error('Copy failed:', err);
      return false;
    }
  },

  // Escape HTML
  escapeHtml: (unsafe) => {
    if (!unsafe) return '';
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  },

  // Simple markdown to HTML (basic, enhanced by marked in production)
  basicMarkdown: (text) => {
    if (!text) return '';
    let html = Utils.escapeHtml(text);
    
    // Bold
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Italic
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
    // Code inline
    html = html.replace(/`(.*?)`/g, '<code>$1</code>');
    // Links
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    
    return html;
  },

  // Detect if text contains code block
  hasCodeBlock: (text) => {
    return /```[\s\S]*?```/.test(text);
  },

  // Extract code blocks
  extractCodeBlocks: (text) => {
    const blocks = [];
    const regex = /```(\w+)?\n?([\s\S]*?)```/g;
    let match;
    while ((match = regex.exec(text)) !== null) {
      blocks.push({
        language: match[1] || 'plaintext',
        code: match[2].trim()
      });
    }
    return blocks;
  },

  // Sleep / delay
  sleep: (ms) => new Promise(resolve => setTimeout(resolve, ms)),

  // Validate API Key format (basic)
  isValidApiKey: (key, provider) => {
    if (!key || key.length < 10) return false;
    
    const patterns = {
      'OpenAI GPT': /^sk-[a-zA-Z0-9]{20,}$/,
      'Google Gemini': /^AIza[0-9A-Za-z\-_]{35}$/,
      'DeepSeek': /^sk-[a-zA-Z0-9]{20,}$/,
      'OpenRouter': /^sk-or-[a-zA-Z0-9\-]{20,}$/,
      'Anthropic Claude': /^sk-ant-[a-zA-Z0-9]{20,}$/,
      'Groq': /^gsk_[a-zA-Z0-9]{20,}$/,
      'Mistral AI': /^[a-zA-Z0-9]{20,}$/,
      'Cohere': /^[a-zA-Z0-9]{20,}$/,
      'Custom API': /^.+$/
    };
    
    const pattern = patterns[provider] || /^.+$/;
    return pattern.test(key.trim());
  },

  // Get provider icon / color
  getProviderColor: (provider) => {
    const colors = {
      'OpenAI GPT': '#10a37f',
      'Google Gemini': '#4285f4',
      'DeepSeek': '#1a73e8',
      'OpenRouter': '#ff6b35',
      'Anthropic Claude': '#d97757',
      'Groq': '#f55036',
      'Mistral AI': '#ff7000',
      'Cohere': '#395cff',
      'Custom API': '#00f3ff'
    };
    return colors[provider] || '#00f3ff';
  },

  // Format file size
  formatFileSize: (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  },

  // Truncate text
  truncate: (str, length = 60) => {
    if (!str) return '';
    return str.length > length ? str.substring(0, length) + '...' : str;
  }
};

// Make globally available
window.Utils = Utils;