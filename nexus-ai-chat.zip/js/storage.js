/**
 * NEXUS AI - Storage Manager
 * Handles all localStorage operations: chats, settings, API keys, theme
 */

const StorageManager = {
  KEYS: {
    API_KEYS: 'nexus_api_keys',
    CURRENT_PROVIDER: 'nexus_current_provider',
    CURRENT_MODEL: 'nexus_current_model',
    CHATS: 'nexus_chats',
    CURRENT_CHAT_ID: 'nexus_current_chat_id',
    SETTINGS: 'nexus_settings',
    THEME: 'nexus_theme',
    LANGUAGE: 'nexus_language',
    AGENT_MODE: 'nexus_agent_mode'
  },

  // Save data
  save: (key, data) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
      return true;
    } catch (e) {
      console.error('Storage save error:', e);
      return false;
    }
  },

  // Load data
  load: (key, defaultValue = null) => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (e) {
      console.error('Storage load error:', e);
      return defaultValue;
    }
  },

  // Remove
  remove: (key) => {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (e) {
      return false;
    }
  },

  // === API Keys Management ===
  getApiKeys: () => {
    return StorageManager.load(StorageManager.KEYS.API_KEYS, {});
  },

  saveApiKey: (provider, key) => {
    const keys = StorageManager.getApiKeys();
    keys[provider] = {
      key: key.trim(),
      addedAt: Date.now(),
      lastUsed: Date.now()
    };
    return StorageManager.save(StorageManager.KEYS.API_KEYS, keys);
  },

  getApiKey: (provider) => {
    const keys = StorageManager.getApiKeys();
    return keys[provider] ? keys[provider].key : null;
  },

  deleteApiKey: (provider) => {
    const keys = StorageManager.getApiKeys();
    delete keys[provider];
    return StorageManager.save(StorageManager.KEYS.API_KEYS, keys);
  },

  updateLastUsed: (provider) => {
    const keys = StorageManager.getApiKeys();
    if (keys[provider]) {
      keys[provider].lastUsed = Date.now();
      StorageManager.save(StorageManager.KEYS.API_KEYS, keys);
    }
  },

  // === Current Session ===
  getCurrentProvider: () => {
    return StorageManager.load(StorageManager.KEYS.CURRENT_PROVIDER, 'OpenAI GPT');
  },

  setCurrentProvider: (provider) => {
    return StorageManager.save(StorageManager.KEYS.CURRENT_PROVIDER, provider);
  },

  getCurrentModel: () => {
    return StorageManager.load(StorageManager.KEYS.CURRENT_MODEL, 'gpt-4o');
  },

  setCurrentModel: (model) => {
    return StorageManager.save(StorageManager.KEYS.CURRENT_MODEL, model);
  },

  // === Chats ===
  getChats: () => {
    return StorageManager.load(StorageManager.KEYS.CHATS, []);
  },

  saveChats: (chats) => {
    return StorageManager.save(StorageManager.KEYS.CHATS, chats);
  },

  getCurrentChatId: () => {
    return StorageManager.load(StorageManager.KEYS.CURRENT_CHAT_ID, null);
  },

  setCurrentChatId: (id) => {
    return StorageManager.save(StorageManager.KEYS.CURRENT_CHAT_ID, id);
  },

  // Create new chat
  createNewChat: (title = 'Chat Baru') => {
    const chats = StorageManager.getChats();
    const newChat = {
      id: Utils.generateId(),
      title: title,
      messages: [],
      provider: StorageManager.getCurrentProvider(),
      model: StorageManager.getCurrentModel(),
      createdAt: Date.now(),
      updatedAt: Date.now(),
      agentMode: StorageManager.getAgentMode()
    };
    chats.unshift(newChat);
    StorageManager.saveChats(chats);
    StorageManager.setCurrentChatId(newChat.id);
    return newChat;
  },

  // Get chat by ID
  getChatById: (id) => {
    const chats = StorageManager.getChats();
    return chats.find(c => c.id === id) || null;
  },

  // Update chat
  updateChat: (chatId, updates) => {
    const chats = StorageManager.getChats();
    const index = chats.findIndex(c => c.id === chatId);
    if (index !== -1) {
      chats[index] = { 
        ...chats[index], 
        ...updates, 
        updatedAt: Date.now() 
      };
      StorageManager.saveChats(chats);
      return chats[index];
    }
    return null;
  },

  // Add message to chat
  addMessageToChat: (chatId, message) => {
    const chats = StorageManager.getChats();
    const index = chats.findIndex(c => c.id === chatId);
    if (index !== -1) {
      if (!chats[index].messages) chats[index].messages = [];
      chats[index].messages.push({
        ...message,
        id: Utils.generateId(),
        timestamp: Date.now()
      });
      chats[index].updatedAt = Date.now();
      
      // Auto update title from first user message
      if (chats[index].messages.length === 1 && message.role === 'user') {
        chats[index].title = Utils.truncate(message.content, 50);
      }
      
      StorageManager.saveChats(chats);
      return chats[index];
    }
    return null;
  },

  // Delete chat
  deleteChat: (chatId) => {
    let chats = StorageManager.getChats();
    chats = chats.filter(c => c.id !== chatId);
    StorageManager.saveChats(chats);
    
    if (StorageManager.getCurrentChatId() === chatId) {
      if (chats.length > 0) {
        StorageManager.setCurrentChatId(chats[0].id);
      } else {
        StorageManager.remove(StorageManager.KEYS.CURRENT_CHAT_ID);
      }
    }
    return chats;
  },

  // === Settings ===
  getSettings: () => {
    const defaultSettings = {
      temperature: 0.7,
      topP: 0.95,
      maxTokens: 4096,
      presencePenalty: 0,
      frequencyPenalty: 0,
      systemPrompt: 'Kamu adalah asisten AI yang sangat membantu, cerdas, dan ramah. Jawab dalam bahasa Indonesia jika pengguna bertanya dalam bahasa Indonesia.',
      customInstructions: '',
      autoSpeak: false,
      streamResponse: true,
      showThinking: true
    };
    const saved = StorageManager.load(StorageManager.KEYS.SETTINGS, {});
    return { ...defaultSettings, ...saved };
  },

  saveSettings: (settings) => {
    return StorageManager.save(StorageManager.KEYS.SETTINGS, settings);
  },

  // === Theme ===
  getTheme: () => {
    return StorageManager.load(StorageManager.KEYS.THEME, 'dark');
  },

  setTheme: (theme) => {
    document.body.classList.toggle('light', theme === 'light');
    return StorageManager.save(StorageManager.KEYS.THEME, theme);
  },

  // === Agent Mode ===
  getAgentMode: () => {
    return StorageManager.load(StorageManager.KEYS.AGENT_MODE, 'default');
  },

  setAgentMode: (mode) => {
    return StorageManager.save(StorageManager.KEYS.AGENT_MODE, mode);
  },

  // === Language ===
  getLanguage: () => {
    return StorageManager.load(StorageManager.KEYS.LANGUAGE, 'id');
  },

  setLanguage: (lang) => {
    return StorageManager.save(StorageManager.KEYS.LANGUAGE, lang);
  },

  // Clear all data (for reset)
  clearAll: () => {
    Object.values(StorageManager.KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  }
};

// Expose globally
window.StorageManager = StorageManager;