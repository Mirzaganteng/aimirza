/**
 * NEXUS AI - API Handler
 * Handles all communication with AI providers, streaming, vision, file processing
 */

const APIHandler = {
  currentController: null, // For aborting requests
  isStreaming: false,

  // Main send message function
  async sendMessage(messages, providerName, model, settings, onChunk, onComplete, onError) {
    const provider = ProviderConfig.getProvider(providerName);
    const apiKey = StorageManager.getApiKey(providerName);

    if (!apiKey) {
      onError(new Error('API Key tidak ditemukan. Silakan login ulang.'));
      return;
    }

    // Abort previous request if any
    if (this.currentController) {
      this.currentController.abort();
    }
    this.currentController = new AbortController();
    this.isStreaming = true;

    StorageManager.updateLastUsed(providerName);

    try {
      let endpoint = provider.endpoint;
      let headers = provider.headers ? provider.headers(apiKey) : { 'Content-Type': 'application/json' };
      let body;

      if (providerName === 'Google Gemini') {
        endpoint = provider.getEndpoint(model, apiKey);
        body = JSON.stringify(provider.buildBody(messages, model, settings));
        // Gemini uses query param key, no Authorization header needed in this setup
        headers = { 'Content-Type': 'application/json' };
      } else if (providerName === 'Anthropic Claude') {
        body = JSON.stringify(provider.buildBody(messages, model, settings));
      } else if (providerName === 'Cohere') {
        body = JSON.stringify(provider.buildBody(messages, model, settings));
      } else {
        // OpenAI compatible (OpenAI, Groq, DeepSeek, OpenRouter, Mistral, Custom)
        body = JSON.stringify(provider.buildBody(messages, model, settings, true));
      }

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: headers,
        body: body,
        signal: this.currentController.signal
      });

      if (!response.ok) {
        const errorText = await response.text();
        let errorMsg = `HTTP ${response.status}`;
        
        try {
          const errorJson = JSON.parse(errorText);
          errorMsg = errorJson.error?.message || errorJson.message || errorText;
        } catch (_) {
          errorMsg = errorText || errorMsg;
        }

        if (response.status === 401) errorMsg = 'API Key tidak valid atau expired.';
        if (response.status === 429) errorMsg = 'Rate limit tercapai. Coba lagi nanti.';
        if (response.status === 400) errorMsg = 'Permintaan tidak valid: ' + errorMsg;

        throw new Error(errorMsg);
      }

      // Handle streaming
      if (provider.streamSupported && response.body) {
        await this.handleStream(response, provider, onChunk, onComplete);
      } else {
        // Non-stream fallback
        const data = await response.json();
        let content = '';
        
        if (provider.parseResponse) {
          content = provider.parseResponse(data);
        } else if (data.choices && data.choices[0]) {
          content = data.choices[0].message?.content || data.choices[0].text || '';
        } else if (data.text) {
          content = data.text;
        } else if (data.candidates) {
          content = data.candidates[0]?.content?.parts?.[0]?.text || '';
        }
        
        onChunk(content);
        onComplete(content);
      }
    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('Request aborted by user');
        onComplete(''); // Treat as complete
      } else {
        console.error('API Error:', error);
        onError(error);
      }
    } finally {
      this.isStreaming = false;
      this.currentController = null;
    }
  },

  // Handle SSE / chunked streaming
  async handleStream(response, provider, onChunk, onComplete) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';
    let fullContent = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        
        // Process complete lines / events
        let lines = buffer.split('\n');
        buffer = lines.pop() || ''; // Keep incomplete line

        for (let line of lines) {
          line = line.trim();
          if (!line) continue;

          if (provider.parseStreamChunk) {
            const result = provider.parseStreamChunk(line);
            if (result.content) {
              fullContent += result.content;
              onChunk(result.content);
            }
            if (result.done) {
              onComplete(fullContent);
              return;
            }
          } else {
            // Generic fallback
            if (line.startsWith('data: ')) {
              const dataStr = line.substring(6).trim();
              if (dataStr === '[DONE]') {
                onComplete(fullContent);
                return;
              }
              try {
                const parsed = JSON.parse(dataStr);
                const delta = parsed.choices?.[0]?.delta?.content || 
                             parsed.delta?.content || '';
                if (delta) {
                  fullContent += delta;
                  onChunk(delta);
                }
              } catch (e) {}
            }
          }
        }
      }

      // Final flush
      if (buffer.trim()) {
        // Try one last parse
        if (provider.parseStreamChunk) {
          const result = provider.parseStreamChunk(buffer.trim());
          if (result.content) {
            fullContent += result.content;
            onChunk(result.content);
          }
        }
      }
      
      onComplete(fullContent);
    } catch (err) {
      console.error('Stream reading error:', err);
      onComplete(fullContent); // Return what we have
    }
  },

  // Stop current generation
  stopGeneration: () => {
    if (APIHandler.currentController) {
      APIHandler.currentController.abort();
      APIHandler.currentController = null;
    }
    APIHandler.isStreaming = false;
  },

  // Process uploaded file (text, image, pdf)
  async processFile(file) {
    return new Promise((resolve, reject) => {
      const fileType = file.type;
      const fileName = file.name;
      const fileSize = file.size;

      // Text files
      if (fileType.startsWith('text/') || 
          fileType === 'application/json' || 
          fileName.endsWith('.md') || 
          fileName.endsWith('.csv')) {
        
        const reader = new FileReader();
        reader.onload = (e) => {
          resolve({
            type: 'text',
            name: fileName,
            content: e.target.result,
            size: fileSize
          });
        };
        reader.onerror = reject;
        reader.readAsText(file);
        return;
      }

      // Images (for vision models)
      if (fileType.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          resolve({
            type: 'image',
            name: fileName,
            content: e.target.result, // base64 data url
            size: fileSize,
            mime: fileType
          });
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
        return;
      }

      // PDF - extract text using pdf.js if available
      if (fileType === 'application/pdf') {
        if (typeof pdfjsLib !== 'undefined') {
          const reader = new FileReader();
          reader.onload = async (e) => {
            try {
              const typedarray = new Uint8Array(e.target.result);
              const pdf = await pdfjsLib.getDocument(typedarray).promise;
              let fullText = '';
              
              for (let i = 1; i <= pdf.numPages; i++) {
                const page = await pdf.getPage(i);
                const textContent = await page.getTextContent();
                const pageText = textContent.items.map(item => item.str).join(' ');
                fullText += `\n--- Halaman ${i} ---\n${pageText}`;
              }
              
              resolve({
                type: 'pdf',
                name: fileName,
                content: fullText.trim(),
                size: fileSize,
                pages: pdf.numPages
              });
            } catch (err) {
              reject(new Error('Gagal membaca PDF: ' + err.message));
            }
          };
          reader.readAsArrayBuffer(file);
        } else {
          // Fallback if pdf.js not loaded
          resolve({
            type: 'pdf',
            name: fileName,
            content: `[File PDF: ${fileName}. Untuk membaca konten lengkap, pdf.js diperlukan. File telah dilampirkan.]`,
            size: fileSize
          });
        }
        return;
      }

      // DOCX basic support (requires JSZip + XML parsing)
      if (fileName.endsWith('.docx') && typeof JSZip !== 'undefined') {
        const reader = new FileReader();
        reader.onload = async (e) => {
          try {
            const zip = await JSZip.loadAsync(e.target.result);
            const docXml = await zip.file('word/document.xml').async('string');
            
            // Very basic text extraction from XML
            const textContent = docXml
              .replace(/<w:p[^>]*>/g, '\n')
              .replace(/<[^>]+>/g, ' ')
              .replace(/\s+/g, ' ')
              .trim();
            
            resolve({
              type: 'docx',
              name: fileName,
              content: textContent.substring(0, 15000) + (textContent.length > 15000 ? '...' : ''),
              size: fileSize
            });
          } catch (err) {
            reject(new Error('Gagal membaca DOCX'));
          }
        };
        reader.readAsArrayBuffer(file);
        return;
      }

      // Fallback for other files
      resolve({
        type: 'file',
        name: fileName,
        content: `[File dilampirkan: ${fileName} (${Utils.formatFileSize(fileSize)}). AI mungkin dapat menganalisis jika model mendukung.]`,
        size: fileSize
      });
    });
  },

  // Build messages array with file context + system prompt
  buildMessages: (chatHistory, newUserMessage, fileData = null, systemPrompt = '', customInstructions = '', agentMode = 'default') => {
    let messages = [];

    // System prompt
    let finalSystem = systemPrompt || 'Kamu adalah asisten AI canggih bernama NEXUS. Jawab dengan jelas, membantu, dan dalam bahasa Indonesia jika diminta.';
    
    if (customInstructions) {
      finalSystem += '\n\nInstruksi Tambahan: ' + customInstructions;
    }

    // Agent specific system prompts
    const agentPrompts = {
      'research': 'Kamu adalah Research Agent. Selalu berikan informasi akurat, kutip sumber jika memungkinkan, dan gunakan pendekatan ilmiah. Struktur jawaban dengan poin-poin jelas.',
      'coding': 'Kamu adalah Coding Agent ahli. Selalu berikan kode yang bersih, beri komentar, jelaskan logika, dan sarankan best practice. Gunakan markdown code block dengan bahasa yang tepat.',
      'writing': 'Kamu adalah Writing Agent profesional. Bantu menulis konten berkualitas tinggi, sesuaikan tone dengan kebutuhan, dan berikan revisi jika diminta.',
      'translation': 'Kamu adalah Translation Agent. Terjemahkan secara akurat sambil mempertahankan makna, nuansa, dan konteks budaya. Berikan alternatif jika ada.',
      'summarizer': 'Kamu adalah Summarizer Agent. Buat ringkasan yang padat, tangkap poin utama, dan pertahankan informasi penting.',
      'websearch': 'Kamu adalah Web Search Agent. Jika informasi terbaru diperlukan, sarankan query pencarian atau gunakan pengetahuan terkini. Selalu verifikasi fakta.'
    };

    if (agentMode && agentMode !== 'default' && agentPrompts[agentMode]) {
      finalSystem = agentPrompts[agentMode] + '\n\n' + finalSystem;
    }

    if (finalSystem) {
      messages.push({ role: 'system', content: finalSystem });
    }

    // Add previous chat history (limit to last ~20 messages to avoid token overflow)
    const recentHistory = chatHistory.slice(-20);
    messages = messages.concat(recentHistory);

    // Current user message + file
    let userContent = newUserMessage;

    if (fileData) {
      if (fileData.type === 'image') {
        // Vision format (OpenAI style)
        userContent = [
          { type: 'text', text: newUserMessage || 'Analisis gambar ini.' },
          { type: 'image_url', image_url: { url: fileData.content } }
        ];
      } else if (fileData.type === 'text' || fileData.type === 'pdf' || fileData.type === 'docx') {
        userContent = `${newUserMessage || 'Baca dan analisis file berikut:'}\n\n--- FILE: ${fileData.name} ---\n${fileData.content}\n--- END FILE ---`;
      } else {
        userContent = `${newUserMessage || ''}\n\n[File dilampirkan: ${fileData.name}]`;
      }
    }

    messages.push({ 
      role: 'user', 
      content: userContent 
    });

    return messages;
  },

  // Simple web search simulation (for Web Search Agent)
  async performWebSearch(query) {
    // In production, integrate real search API here (SerpApi, Bing, etc.)
    // For now, return mock + note
    return {
      query: query,
      results: [
        { title: `Hasil pencarian untuk: ${query}`, snippet: 'Ini adalah simulasi. Integrasikan API pencarian nyata untuk hasil aktual.', url: '#' },
        { title: 'Informasi Terkini', snippet: 'NEXUS AI mendukung tool calling dan web search agent.', url: '#' }
      ],
      note: 'Web search saat ini dalam mode simulasi. Hasil akan lebih akurat dengan integrasi API eksternal.'
    };
  }
};

// Expose
window.APIHandler = APIHandler;