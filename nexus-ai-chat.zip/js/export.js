/**
 * NEXUS AI - Export Functions
 * Export chat to TXT, PDF, JSON. Requires jsPDF for PDF.
 */

const ExportManager = {
  // Export current chat to TXT
  exportToTXT: (chat) => {
    if (!chat || !chat.messages || chat.messages.length === 0) {
      alert('Tidak ada pesan untuk diekspor.');
      return;
    }

    let content = `NEXUS AI Chat Export\n`;
    content += `Judul: ${chat.title}\n`;
    content += `Provider: ${chat.provider} | Model: ${chat.model}\n`;
    content += `Tanggal: ${new Date(chat.createdAt).toLocaleString('id-ID')}\n`;
    content += `=====================================\n\n`;

    chat.messages.forEach((msg, index) => {
      const role = msg.role === 'user' ? 'Anda' : 'NEXUS AI';
      const time = msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString('id-ID') : '';
      content += `[${role} - ${time}]\n${msg.content}\n\n`;
      if (index < chat.messages.length - 1) content += `---\n\n`;
    });

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${chat.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (window.showToast) window.showToast('Chat diekspor sebagai TXT', 'success');
  },

  // Export to JSON (full data)
  exportToJSON: (chat) => {
    if (!chat) return;

    const exportData = {
      ...chat,
      exportedAt: Date.now(),
      version: '1.0',
      app: 'NEXUS AI'
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexus-chat-${chat.id}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (window.showToast) window.showToast('Chat diekspor sebagai JSON', 'success');
  },

  // Export to PDF using jsPDF
  exportToPDF: async (chat) => {
    if (!chat || !chat.messages || chat.messages.length === 0) {
      alert('Tidak ada pesan untuk diekspor.');
      return;
    }

    if (typeof window.jspdf === 'undefined' && typeof jsPDF === 'undefined') {
      // Load jsPDF dynamically if not present
      const script = document.createElement('script');
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
      script.onload = () => ExportManager._doPDFExport(chat);
      document.head.appendChild(script);
      return;
    }

    ExportManager._doPDFExport(chat);
  },

  _doPDFExport: (chat) => {
    const { jsPDF } = window.jspdf || window;
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    let y = 20;

    // Header
    doc.setFontSize(18);
    doc.setTextColor(0, 120, 255);
    doc.text('NEXUS AI - Chat Export', pageWidth / 2, y, { align: 'center' });
    y += 10;

    doc.setFontSize(11);
    doc.setTextColor(80);
    doc.text(`Judul: ${chat.title}`, 20, y);
    y += 7;
    doc.text(`Provider: ${chat.provider}  |  Model: ${chat.model}`, 20, y);
    y += 7;
    doc.text(`Dibuat: ${new Date(chat.createdAt).toLocaleString('id-ID')}`, 20, y);
    y += 12;

    // Line
    doc.setDrawColor(200);
    doc.line(20, y, pageWidth - 20, y);
    y += 10;

    // Messages
    doc.setFontSize(10);
    doc.setTextColor(30);

    chat.messages.forEach((msg) => {
      if (y > 260) {
        doc.addPage();
        y = 20;
      }

      const role = msg.role === 'user' ? 'Anda' : 'NEXUS';
      const time = msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '';

      // Role header
      doc.setFont(undefined, 'bold');
      doc.setTextColor(msg.role === 'user' ? 0 : 100, msg.role === 'user' ? 120 : 100, msg.role === 'user' ? 255 : 200);
      doc.text(`${role} (${time})`, 20, y);
      y += 6;

      // Content (wrap text)
      doc.setFont(undefined, 'normal');
      doc.setTextColor(40);
      
      const contentLines = doc.splitTextToSize(msg.content || '', pageWidth - 45);
      doc.text(contentLines, 22, y);
      y += (contentLines.length * 5) + 8;

      // Separator
      doc.setDrawColor(220);
      doc.line(20, y, pageWidth - 20, y);
      y += 6;
    });

    // Footer
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text('Diekspor dari NEXUS AI • ' + new Date().toLocaleDateString('id-ID'), pageWidth / 2, 290, { align: 'center' });

    doc.save(`${chat.title.replace(/[^a-z0-9]/gi, '_')}.pdf`);
    
    if (window.showToast) window.showToast('Chat diekspor sebagai PDF', 'success');
  }
};

window.ExportManager = ExportManager;